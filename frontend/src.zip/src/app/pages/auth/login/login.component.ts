import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';


import { SharedModule } from 'src/app/shared/shared.module';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [SharedModule, RouterModule, FormsModule, HttpClientModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss', '../authentication.scss']
})
export default class LoginComponent {

  hide = true;
  email: string = '';
  password: string = '';

  // eslint-disable-next-line @angular-eslint/prefer-inject
  constructor(private http: HttpClient, private router:Router) {}


  login() {
    if (!this.email || !this.password) {
      alert('Please fill in both email and password.');
      return;
    }

    const loginData = {
      email: this.email,
      password: this.password
    };

    console.log('Attempting login with:', loginData);

    this.http.post<any>('http://127.0.0.1:8000/auth/login', loginData).subscribe({
      next: (res) => {
        console.log('Login successful:', res);
        localStorage.setItem('token', res.access_token);
        alert('Login successful!');
        this.router.navigate(['/events']);
      },
      error: (err) => {
        console.error('Login failed:', err);
        alert('Invalid email or password.');
      }
    });
  }
}